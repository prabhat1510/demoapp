package com.sapient.core;

public class MessageService {

    public static String get() {
        return "Hello JUnit 5";
    }

}
